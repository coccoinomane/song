#!/bin/sh

# Parse arguments
gnuplot_script="$1"
index_var="$(($2+2))"
index_k="$3"
shift; shift; shift;
gnuplot_opts="title columnhead $*"

# Executable that prints the data
bin="./print_sources_first_order"

# Save sources
$bin params.pre params.ini $index_k > temp.txt

# Print some info
head -n4 temp.txt

# Plot
$gnuplot_script temp.txt "using 1:$index_var" $gnuplot_opts