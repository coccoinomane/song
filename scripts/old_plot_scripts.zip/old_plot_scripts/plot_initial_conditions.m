function plot_initial_conditions(filepath, k1, k2, cosk1k2, eta_index=[])
%   PLOT_INITIAL_CONDITIONS   Compare the initial conditions calculated by CLASS2 with those hard coded in this script.
%     [OUTPUT VARIABLES] = PLOT_INITIAL_CONDITIONS(FILEPATH, ETA_INDEX=[end])
% 
%   Feed the script a text file given by the 'print_initial_conditions_2nd_order' C program.  The
%   script will check if the content of the file matches the true initial conditions, hard-coded
%   in this script.  The comparison is made visually through two plots.  Make sure that the file
%   passed to the script matches the k1, k2, and cosk1k2 arguments.
%
%   This script basically checks that the initial conditions are passed correctly inside CLASS2.  
%   For now the script only checks the initial conditions for the metric variable eta, but it should be
%   easy to generalize it.
%
%   Created by Guido Walter Pettinari on 2011-08-07.

  # Read in file from the CLASS2 code, skipping the first 4 row since they may contain text
  initial_conditions_matrix = dlmread(filepath, " ", 5, 0);

  # By default, assume the index of eta in the initial conditions file is the last one.
  if (isempty(eta_index) || eta_index > columns(initial_conditions_matrix))
    eta_index = columns(initial_conditions_matrix) - 1;
  endif
  
  # Extract eta from matrix
  eta_from_CLASS = initial_conditions_matrix(:,eta_index);
  
  # Time samping
  tau = initial_conditions_matrix(:,1);

  # Parameters
  k_sq = k1^2 + k2^2 + 2*k1*k2*cosk1k2;
  C = D = 1/2;
  C_sq = C^2;
  mu_sq = cosk1k2^2;
  ktau_two = k_sq .* tau .* tau;

  # Compute eta
  eta_from_octave = 2*D + 1/2*C_sq.*ktau_two*(1+mu_sq) + (1 - 3*mu_sq)*(28*C_sq - 16*C_sq.*log(tau));

  # Fractional difference
  abs_frac = abs(1 - eta_from_CLASS./eta_from_octave);

  # Plot
  subplot(2,1,1)
  loglog (tau, abs(eta_from_octave), tau, abs(eta_from_CLASS))
  legend ("eta from octave", "eta from CLASS")
  subplot(2,1,2)
  loglog (tau, abs_frac)
  title ("absolute fractional difference")

  # Max relative difference
  printf("Max absolute relative difference = %e\n", max(abs_frac))

endfunction