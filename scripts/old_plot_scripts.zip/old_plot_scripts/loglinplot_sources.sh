#!/bin/sh

./plot_sources_generic.sh loglinplot $*