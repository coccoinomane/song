#!/bin/sh

### Parse arguments
# Gnuplot shell script, usually stored in ~/my_projects/shell_scripts.
# Examples are plot, loglinplot, loglogplot, logplot
gnuplot_script="$1"
index_var="$(($2+2))"
index_k1="$3"
index_k2="$4"
index_cosk1k2="$5"
shift; shift; shift; shift; shift;
gnuplot_opts="title columnhead $*"

# Executable that prints the data
bin="./print_initial_conditions_2nd_order"

# Save sources
$bin params.pre params.ini $index_k1 $index_k2 $index_cosk1k2 > temp.txt

# Print some info
head -n4 temp.txt

# Plot
cmd="$gnuplot_script temp.txt using 1:$index_var $gnuplot_opts"
echo "Shell command: \"$cmd\""
$cmd